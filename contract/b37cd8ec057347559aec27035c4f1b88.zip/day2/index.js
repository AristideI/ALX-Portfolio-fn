// // lexical scope 
// // scope in Js 
// // closure in js



// function calculateSum(arr){
//     // let sum = 30;
//     for(let i of arr){
//         let sum = 0;
//         sum += i
//     }
//     console.log(sum)
// }

// calculateSum([1,2,3])



// function calculateSum(){
//     return 5+7
// }

// console.log(calculateSum())


// (function calculateSum1(){
//     console.log(4+19)
// })()

// const calculateSum2 = function (a,b){
//     console.log(40+19)
//     console.log(a*b)
// }

// calculateSum2(1,3)


// const calculateSum2 =(a,b) => {
//    return a*b
// }

// const calculateSum2 =(a,b) => a*b

// console.log(calculateSum2(7,6))


// function calculateSum(d){
//     return this.a + this.b + this.c +d
// }

// const nums={
//     a:2,
//     b:4,
//     c:6
// }

// console.log( calculateSum.call(nums,1) )



// function vowels(str){
//     let sum=0
//     for (let i of str)
//         if(['a','e','i','o','u'].includes(i))
//             sum++
//     return sum
// }

// console.log(vowels('The quick brown fox'))
